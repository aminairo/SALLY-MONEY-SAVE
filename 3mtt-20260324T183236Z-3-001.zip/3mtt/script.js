let currentUser = localStorage.getItem("currentUser");

function showLogin() {
    document.getElementById("loginBox").style.display = "block";
    document.getElementById("registerBox").style.display = "none";
}

function showRegister() {
    document.getElementById("loginBox").style.display = "none";
    document.getElementById("registerBox").style.display = "block";
}

function register() {
    let user = regUser.value;
    let pass = regPass.value;

    let users = JSON.parse(localStorage.getItem("users")) || {};

    users[user] = { password: pass, total: 0, goal: 0, history: [] };

    localStorage.setItem("users", JSON.stringify(users));

    // AUTO LOGIN
    localStorage.setItem("currentUser", user);

    alert("✅ Account created!");
    window.location.href = "dashboard.html";
}

function login() {
    let user = loginUser.value;
    let pass = loginPass.value;

    let users = JSON.parse(localStorage.getItem("users"));

    if (!users[user] || users[user].password !== pass) {
        alert("Invalid login");
        return;
    }

    localStorage.setItem("currentUser", user);
    window.location.href = "dashboard.html";
}

function checkUser() {
    if (!currentUser) {
        window.location.href = "auth.html";
        return;
    }

    document.getElementById("username").innerText = currentUser;
    loadData();
}

function loadData() {
    let users = JSON.parse(localStorage.getItem("users"));
    let data = users[currentUser];

    total.innerText = data.total;
    goal.innerText = data.goal;

    let percent = data.goal ? (data.total / data.goal) * 100 : 0;
    progress.style.width = percent + "%";

    message.innerText = percent >= 100 ? "🎉 Goal reached!" : "Keep saving!";

    history.innerHTML = data.history.length
        ? data.history.map(h => `<li>${h}</li>`).join("")
        : "<li>No savings yet</li>";
}

function setGoal() {
    let users = JSON.parse(localStorage.getItem("users"));
    users[currentUser].goal = parseInt(goalInput.value);
    localStorage.setItem("users", JSON.stringify(users));
    loadData();
}

function addSavings() {
    let users = JSON.parse(localStorage.getItem("users"));
    let data = users[currentUser];

    let amount = parseInt(amountInput.value);
    data.total += amount;

    data.history.push(`₦${amount} saved on ${new Date().toLocaleString()}`);

    localStorage.setItem("users", JSON.stringify(users));
    loadData();
}

function logout() {
    localStorage.removeItem("currentUser");
    window.location.href = "index.html";
}

function calculatePlan() {
    let amount = parseInt(document.getElementById("targetAmount").value);
    let months = parseInt(document.getElementById("months").value);

    if (!amount || !months) return;

    let monthly = amount / months;
    let weekly = monthly / 4;
    let daily = monthly / 30;

    document.getElementById("planResult").innerHTML = `
        <p>Monthly: ₦${monthly.toFixed(2)}</p>
        <p>Weekly: ₦${weekly.toFixed(2)}</p>
        <p>Daily: ₦${daily.toFixed(2)}</p>
    `;
}